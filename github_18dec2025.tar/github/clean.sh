#!/bin/sh
rm -f firstTreesPreCherry
rm -f firstTreesPreSymmetry
rm -f secondTrees
rm -f firstTrees
rm -f myfile.txt
rm -f forilp.txt
rm -f template.ilp
rm -f forests
rm -f forestNames
rm -f template2.ilp
rm -f template3.ilp
rm -f vanilla.ilp
rm -f modified.ilp
rm -f vanilla.out
rm -f modified.out
rm -f vanillaOpt
rm -f modifiedOpt
