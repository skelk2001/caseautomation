#!/bin/sh

rm -f collectPatterns

for i in `cat $1`
do
echo $i > littleFile
STRIPPED=`cat littleFile | sed 's/X[0-9]\+/Y/g'`
echo $i " " $STRIPPED >> collectPatterns
rm -f littleFile
done


ORIGINAL=`cat collectPatterns  | wc -l`
echo "Found $ORIGINAL trees before symmetry reduction:"
cat $1

echo "Found these unique patterns:"
cat collectPatterns | gawk '{print $2}' | sort | uniq > seenPatterns
cat seenPatterns
echo `cat seenPatterns | wc -l`" patterns in total."

echo "Selecting one tree per pattern."

cat collectPatterns | nawk '
{
if( seen[$2] == "" )
	{
	seen[$2] = "1"
	print $0;
	}
}' > selected

cat selected

echo "`cat selected | wc -l`" "canonical trees generated."


echo "Putting these canonical trees (without their pattern) in file $2."
cat selected | gawk '{print $1} ' > $2


cat $2

rm -f seenPatterns
rm -f collectPatterns
rm -f selected
