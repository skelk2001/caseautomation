#!/bin/sh

	echo "Getting expanded trees from $1"

	cat $1

	#echo "(Internally reversing the order of the trees because of the convention adopted by the ILP solver)"

	tail -1 $1 > forilp.txt
	head -1 $1 >> forilp.txt

	java TemplateILP < forilp.txt > template.ilp

	grep -v "CUTCONSTRAINT" template.ilp > template2.ilp

	grep -v "FOREST[0-9]" template2.ilp > template3.ilp

	grep -v "PROTECTCONSTRAINT" template3.ilp > vanilla.ilp
	cp template3.ilp modified.ilp

	glpsol --cpxlp vanilla.ilp -o vanilla.out > /dev/null
	glpsol --cpxlp modified.ilp -o modified.out > /dev/null
	grep Objective vanilla.out | gawk '{print $4}' | tee vanillaOpt | gawk '{ print "OPT without modification: " $0 }' 
	grep Objective modified.out | gawk '{print $4}' | tee modifiedOpt | gawk '{ print "OPT with modification: " $0 }'


	diff vanillaOpt modifiedOpt || { echo 'BASE CASE IS FALSE!!!!!!!'; exit; }

echo "No counter-example found: the base case holds!"



