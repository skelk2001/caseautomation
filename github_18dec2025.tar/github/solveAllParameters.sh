#!/bin/sh

# It is easiest to use this by calling it via the 'proof....sh' and 'disproof....sh' wrapper scripts, but
# in principle this can also be run directly.


echo "Reading trees from $1."
echo "Will add up to $2 taxa."

# if yes, we throw away tree/forest pairs where the first tree has a cherry.
REMOVECHERRIES=$3

# logging ... can get very large, very quickly!
LOGS=$4

# if you don't want to start with |X \setminus K| = 0.
STARTTAXA=$5

# default mode is "exists" but setting this to yes puts it in "forall" mode
FORALL=$6

# set to "yes" if you want to allow all (relevant) forests F' of T' (otherwise it is just T')
ALLOWFORESTS=$7

# set to "yes" if you want to allow forests F' that contain singletons
ALLOWSINGLETONFORESTS=$8


echo "REMOVECHERRIES = $REMOVECHERRIES"
echo "LOGS = $LOGS"
echo "STARTTAXA = $STARTTAXA"
echo "FORALL = $FORALL"
echo "ALLOWFORESTS = $ALLOWFORESTS"
echo "ALLOWSINGLETONFORESTS = $ALLOWSINGLETONFORESTS"
echo "Note: in the execution below, FOREST1 indicates the situation F' = T'."


NAME=`basename "$1" | sed 's/\.[^.]*$//'`
#echo "Logging prefix: $NAME"

if [ $LOGS = "yes" ];
then
echo "Logging activated. Prefix will be: $NAME"
echo "These log files will be placed in the directory ./logs which will be created if necessary."
mkdir logs > /dev/null 2>/dev/null
fi

MYFIRST=`head -1 $1`
MYSECOND=`tail -1 $1`

echo "*****************************************************************"

echo "First tree: $MYFIRST"
echo "Second tree: $MYSECOND"

echo "*****************************************************************"


echo "Going to try expansions with $STARTTAXA taxa, ... all the way up to $2 taxa".

# you can change this to a higher number just to start |X \setminus K| at a higher number
TOADD=$STARTTAXA;

while [ $TOADD -le $2 ];
do

echo "*****************************************************************"
echo "********* OUTERLOOP: |X \setminus K| has exactly $TOADD taxa. ********"
echo "*****************************************************************"

java ExpandSingleTree $MYFIRST $TOADD | grep 'Expanded' | gawk '{print $3}' > firstTreesPreSymmetry
java ExpandSingleTree $MYSECOND $TOADD | grep 'Expanded' | gawk '{print $3}' > secondTrees

# echo "Removing symmetries from first trees

./filter.sh ./firstTreesPreSymmetry ./firstTreesPreCherry

echo "======================="
echo "Expansions first tree:"
cat firstTreesPreCherry

FIRST=`cat firstTreesPreCherry | wc -l`

#echo $FIRST

if [ $REMOVECHERRIES = "yes" ];
then

echo "Removing expansions of first tree that have a cherry in the first tree"
echo "(outside the preserved region)."

HAVECHERRY=`cat firstTreesPreCherry | grep '(X[0-9]*,X[0-9]*)' | wc -l`

echo "$HAVECHERRY of the trees had such a cherry."

cat firstTreesPreCherry | grep -v '(X[0-9]*,X[0-9]*)' > firstTrees

echo "Expansions of first tree after removing trees with cherries:"

cat firstTrees
else
echo "Not removing any instances where the first tree has a cherry outside the preserved region."

cp firstTreesPreCherry firstTrees
fi


FIRST=`cat firstTrees | wc -l`

#echo $FIRST


echo "======================="
echo "Expansions second tree:"
cat secondTrees

SECOND=`cat secondTrees | wc -l`

#echo $SECOND

echo "======================="
echo "Summary:"
echo "$FIRST first trees"
echo "$SECOND second trees"
echo "Total number of tree pairs:"
expr $FIRST \* $SECOND

echo "======================="

TREEPAIR=1;

INNER=1;

while [ $INNER -le $FIRST ];
do

OUTER=1;

	while [ $OUTER -le $SECOND ];
	do
	echo "======================"

	echo "Combination $INNER $OUTER (i.e. tree pair $TREEPAIR)"
	
	cat firstTrees | head -$INNER | tail -1 > myfile.txt
	cat secondTrees | head -$OUTER | tail -1 >> myfile.txt

	cat myfile.txt

	#echo "(Internally reversing the order of the trees because of the convention adopted by the ILP solver)"

	tail -1 myfile.txt > forilp.txt
	head -1 myfile.txt >> forilp.txt

	if [ $ALLOWSINGLETONFORESTS = "yes" ];
	then
	java TemplateILP yes < forilp.txt > template.ilp	
	else
	java TemplateILP no < forilp.txt > template.ilp
	fi

	if [ $LOGS = "yes" ];
	then
	echo "Logging...(1)"
	cp template.ilp "./logs/${NAME}_${INNER}_${OUTER}.treetree"
	fi


	if [ $ALLOWFORESTS = "yes" ];
	then
	echo "Considering all the forests. (Singleton forests allowed = $ALLOWSINGLETONFORESTS)"
	grep "FOREST" template.ilp > forests
	else
	echo "Only considering when the forest is a tree -- no cuts made. (FOREST1 makes no cuts)."
	grep "FOREST" template.ilp | head -1 > forests
	fi

	#cat forests

	#TOTFOREST=`wc -l forests`

	#echo "There are $TOTFOREST to consider."	

	cat forests | gawk '{print $1}' > forestNames

	
	if [ $FORALL = "no" ]
	then
	grep -v "CUTCONSTRAINT" template.ilp > template2.ilp
	else
	grep -v "PROTECTCONSTRAINT" template.ilp > template2.ilp
	fi


	for i in `cat forestNames`
	do

	#echo "Processing forest $i"

	grep "$i" forests

	cat template2.ilp | gawk -f rip.gawk $i > template3.ilp

	# now we produce two versions, one vanilla (no modification) and one modified (with protection or
	# cutting, depending on whether we are in FORALL mode or not.

	if [ $FORALL = "no" ]
	then

	grep -v "PROTECTCONSTRAINT" template3.ilp > vanilla.ilp
	cp template3.ilp modified.ilp

	else

	grep -v "CUTCONSTRAINT" template3.ilp > vanilla.ilp
	cp template3.ilp modified.ilp

	fi


	if [ $LOGS = "yes" ];
	then
	echo "Logging... (2)"

		
	FNUM=`echo "$i" | grep '[0-9]*' -o`
	cp modified.ilp "./logs/${NAME}_${INNER}_${OUTER}_${FNUM}.modified"
	cp vanilla.ilp "./logs/${NAME}_${INNER}_${OUTER}_${FNUM}.vanilla"
	fi


	glpsol --cpxlp vanilla.ilp -o vanilla.out > /dev/null
	glpsol --cpxlp modified.ilp -o modified.out > /dev/null
	grep Objective vanilla.out | gawk '{print $4}' | tee vanillaOpt | gawk '{ print "OPT without modification: " $0 }' 
	grep Objective modified.out | gawk '{print $4}' | tee modifiedOpt | gawk '{ print "OPT with modification: " $0 }'


	if [ $FORALL = "no" ]
	then
	diff vanillaOpt modifiedOpt || { echo '!!!!!!!!!!!!!!!!!!!!!!\nCounter-example found:\nBASE CASE IS FALSE!'; exit; }
	else
        diff vanillaOpt modifiedOpt && { echo '!!!!!!!!!!!!!!!!!!!!!!\nCounter-example found:\nBASE CASE IS FALSE!'; exit; }
	fi

	done



	OUTER=`expr $OUTER + 1`

	TREEPAIR=`expr $TREEPAIR + 1`

	done
INNER=`expr $INNER + 1`
done


TOADD=`expr $TOADD + 1`
done



echo "----------------------------------------------"
echo "----------------------------------------------"
echo "No counter-example found: BASE CASE TRUE!"
echo "----------------------------------------------"
echo "----------------------------------------------"



