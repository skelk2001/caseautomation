#!/bin/sh

sh ./solveAllParameters.sh $1 $2 yes no 0 no yes no

sh ./clean.sh


# meaning of the parameters:

#echo "Reading trees from $1."
#echo "Will add up to $2 taxa."

# if yes, we throw away tree/forest pairs where the first tree has a cherry.
#REMOVECHERRIES=$3

# logging ... can get very large, very quickly!
#LOGS=$4

# if you don't want to start with |X \setminus K| = 0.
#STARTTAXA=$5

# default mode is "exists" but setting this to yes puts it in "forall" mode
#FORALL=$6

# set to "yes" if you want to allow all (relevant) forests F' of T' (otherwise it is just T')
#ALLOWFORESTS=$7

# set to "yes" if you want to allow forests F' that contain singletons
#ALLOWSINGLETONFORESTS=$8
