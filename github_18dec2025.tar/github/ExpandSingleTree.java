import java.util.*;
import java.util.stream.Collectors;

public class ExpandSingleTree {

    static class Node {
        String label;
        Node left, right;

        Node(String label) { this.label = label; }
        Node(Node left, Node right) { this.left = left; this.right = right; }

        boolean isLeaf() { return left == null && right == null; }

        Node copy() { return isLeaf() ? new Node(label) : new Node(left.copy(), right.copy()); }

        // Standard Newick (for display)
        String toNewick() {
            if (isLeaf()) return label;
            if (left != null && right != null)
                return "(" + left.toNewick() + "," + right.toNewick() + ")";
            else if (left != null)
                return left.toNewick();
            else if (right != null)
                return right.toNewick();
            else
                return "";
        }

        // Canonical Newick (for deduplication)
        String toCanonicalNewick() {
            if (isLeaf()) return label;
            List<String> parts = new ArrayList<>();
            if (left != null) parts.add(left.toCanonicalNewick());
            if (right != null) parts.add(right.toCanonicalNewick());
            Collections.sort(parts); // deduplicate symmetric trees
            if (parts.size() == 2)
                return "(" + parts.get(0) + "," + parts.get(1) + ")";
            else if (parts.size() == 1)
                return parts.get(0);
            else
                return "";
        }
    }

    // ===== Newick parser =====
    static class Parser {
        String s; int i;
        Parser(String s) { this.s = s; }

        Node parse() {
            skip();
            if (peek() == '(') {
                next();
                Node left = parse();
                skip(); expect(',');
                Node right = parse();
                skip(); expect(')');
                return new Node(left, right);
            } else {
                return new Node(parseLabel());
            }
        }

        String parseLabel() {
            StringBuilder sb = new StringBuilder();
            while (i<s.length() && "(),; ".indexOf(s.charAt(i))==-1) sb.append(s.charAt(i++));
            return sb.toString();
        }

        void skip() { while (i<s.length() && s.charAt(i)==' ') i++; }
        char peek() { return s.charAt(i); }
        void next() { i++; }
        void expect(char c) { if (s.charAt(i)!=c) throw new RuntimeException("Expected "+c); i++; }
    }

    // ===== Collect letter-labeled leaves =====
    static List<String> collectLetters(Node n) {
        List<String> letters = new ArrayList<>();
        collectLettersRec(n, letters);
        return letters;
    }

    static void collectLettersRec(Node n, List<String> letters) {
        if (n==null) return;
        if (n.isLeaf() && !n.label.matches("\\d+")) letters.add(n.label);
        else { collectLettersRec(n.left, letters); collectLettersRec(n.right, letters); }
    }

    // ===== Replace letter with a subtree, preserve numerical leaves =====
    static Node replace(Node n, Map<String, Node> mapping) {
        if (n == null) return null;
        if (n.isLeaf()) {
            if (mapping.containsKey(n.label)) {
                Node sub = mapping.get(n.label);
                return sub == null ? null : sub.copy();
            } else {
                // Keep numerical leaf
                return new Node(n.label);
            }
        }
        Node left = replace(n.left, mapping);
        Node right = replace(n.right, mapping);
        if (left == null && right == null) return null;
        return new Node(left, right);
    }

    // ===== Generate integer compositions =====
    static List<int[]> generateAllocations(int numLetters, int k) {
        List<int[]> results = new ArrayList<>();
        backtrackAllocations(numLetters, k, 0, new int[numLetters], results);
        return results;
    }

    static void backtrackAllocations(int n, int remaining, int index, int[] current, List<int[]> results) {
        if (index == n) {
            if (remaining == 0) results.add(current.clone());
            return;
        }
        for (int i=0; i<=remaining; i++) {
            current[index] = i;
            backtrackAllocations(n, remaining-i, index+1, current, results);
        }
    }

    // ===== Generate all rooted binary trees on a set of labels (deduplicated) =====
    static List<Node> generateAllBinaryTrees(List<String> labels) {
        if (labels.isEmpty()) return Collections.singletonList(null);
        if (labels.size() == 1) return Collections.singletonList(new Node(labels.get(0)));

        Set<String> seen = new HashSet<>();
        List<Node> result = new ArrayList<>();
        List<String> sorted = new ArrayList<>(labels);
        Collections.sort(sorted);

        for (int i=1;i<sorted.size();i++) {
            for (List<String> leftLabels : combinations(sorted,i)) {
                List<String> rightLabels = new ArrayList<>(sorted);
                rightLabels.removeAll(leftLabels);
                for (Node l : generateAllBinaryTrees(leftLabels)) {
                    for (Node r : generateAllBinaryTrees(rightLabels)) {
                        Node n = new Node(l,r);
                        String canon = n.toCanonicalNewick();
                        if (!seen.contains(canon)) {
                            seen.add(canon);
                            result.add(n);
                        }
                    }
                }
            }
        }
        return result;
    }

    // ===== Combinations helper =====
    static List<List<String>> combinations(List<String> items, int k) {
        List<List<String>> res = new ArrayList<>();
        combineHelper(items,k,0,new ArrayList<>(),res);
        return res;
    }

    static void combineHelper(List<String> items, int k, int start, List<String> cur, List<List<String>> res) {
        if (cur.size() == k) { res.add(new ArrayList<>(cur)); return; }
        for (int i=start;i<items.size();i++) {
            cur.add(items.get(i));
            combineHelper(items,k,i+1,cur,res);
            cur.remove(cur.size()-1);
        }
    }

    // ===== Enumerate all expansions =====
    static void enumerateExpansions(Node tree, List<String> letters, List<String> labels) {
        List<int[]> allocations = generateAllocations(letters.size(), labels.size());
        int[] counter = new int[1];

        for (int[] alloc : allocations) {
            enumerateSubsets(tree, letters, labels, alloc, 0, new HashMap<>(), new HashSet<>(), counter);
        }
    }

    static void enumerateSubsets(Node tree, List<String> letters, List<String> labels, int[] alloc,
                                 int index, Map<String, Node> currentMapping, Set<String> used, int[] counter) {
        if (index == letters.size()) {
            Node expanded = replace(tree, currentMapping);
            counter[0]++;
            System.out.println("=== Expansion "+counter[0]+" ===");
            for (String l : letters)
                System.out.println("  "+l+" = "+(currentMapping.get(l)==null ? "∅" : currentMapping.get(l).toNewick()));
            System.out.println("Expanded tree: "+(expanded==null ? "∅" : expanded.toNewick())+";");
            return;
        }

        String letter = letters.get(index);
        int m = alloc[index];
        if (m==0) {
            Map<String, Node> newMap = new HashMap<>(currentMapping);
            newMap.put(letter,null);
            enumerateSubsets(tree, letters, labels, alloc, index+1, newMap, used, counter);
        } else {
            List<String> available = labels.stream().filter(l->!used.contains(l)).collect(Collectors.toList());
            for (List<String> subset : combinations(available, m)) {
                Set<String> newUsed = new HashSet<>(used); newUsed.addAll(subset);
                for (Node t : generateAllBinaryTrees(subset)) {
                    Map<String, Node> newMap = new HashMap<>(currentMapping);
                    newMap.put(letter, t);
                    enumerateSubsets(tree, letters, labels, alloc, index+1, newMap, newUsed, counter);
                }
            }
        }
    }

    // ===== Main =====
    public static void main(String[] args) {
        if (args.length!=2) { System.out.println("Usage: java ExpandSingleTree <Tree> <k>"); return; }

        Node tree = new Parser(args[0]).parse();
        int k = Integer.parseInt(args[1]);

        List<String> letters = collectLetters(tree);
        List<String> labels = new ArrayList<>();
        for (int i=1;i<=k;i++) labels.add("X"+i);

        enumerateExpansions(tree, letters, labels);
    }
}
