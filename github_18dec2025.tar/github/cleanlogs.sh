#!/bin/sh
cd logs
rm *
cd ..

